from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
import hashlib

app = Flask(__name__)
CORS(app)

def connect_db():
    return sqlite3.connect("database.db")

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

@app.route("/auth/signup", methods=["POST"])
def signup():
    data = request.json
    fullname = data["full_name"]
    email = data["email"]
    username = data["username"]
    password = hash_password(data["password"])

    conn = connect_db()
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO users (fullname, email, username, password) VALUES (?, ?, ?, ?)",
                       (fullname, email, username, password))
        conn.commit()
        return jsonify({"message": "Signup successful!"}), 200
    except sqlite3.IntegrityError:
        return jsonify({"message": "Username already exists!"}), 400
    finally:
        conn.close()

@app.route("/auth/login", methods=["POST"])
def login():
    data = request.json
    username = data["username"]
    password = hash_password(data["password"])

    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
    user = cursor.fetchone()

    if user:
        return jsonify({"message": "Login successful!", "token": "fake-jwt-token"}), 200
    else:
        return jsonify({"message": "Invalid username or password"}), 401

@app.route("/profile/save", methods=["POST"])
def save_profile():
    data = request.json
    username = data["username"]
    college = data["college"]
    skills = data["skills"]
    education = data["education"]

    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM profiles WHERE username=?", (username,))
    existing = cursor.fetchone()

    if existing:
        cursor.execute("UPDATE profiles SET college=?, skills=?, education=? WHERE username=?",
                       (college, skills, education, username))
    else:
        cursor.execute("INSERT INTO profiles (username, college, skills, education) VALUES (?, ?, ?, ?)",
                       (username, college, skills, education))

    conn.commit()
    conn.close()
    return jsonify({"message": "Profile saved successfully"}), 200

@app.route("/profile/get/<username>", methods=["GET"])
def get_profile(username):
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("SELECT college, skills, education FROM profiles WHERE username=?", (username,))
    row = cursor.fetchone()
    conn.close()

    if row:
        college, skills, education = row
        return jsonify({
            "college": college,
            "skills": skills,
            "education": education
        }), 200
    else:
        return jsonify({"message": "Profile not found"}), 404

if __name__ == "__main__":
    app.run(debug=True)
